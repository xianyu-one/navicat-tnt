#pragma once
#include "patch_solution.hpp"

namespace nkg {

    template<int major_ver0, int major_ver1, int minor_ver0, int minor_ver1>
    class patch_solution_since;

}
